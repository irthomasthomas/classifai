from .classifai import main
